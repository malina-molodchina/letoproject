# streamlit-demo-2021
Based on [this](https://medium.com/analytics-vidhya/how-to-deploy-your-streamlit-app-on-heroku-for-free-284c96c2a06d) tutorial.
